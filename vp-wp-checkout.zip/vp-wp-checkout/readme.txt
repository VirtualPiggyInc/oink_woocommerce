=== Oink Payment gateway ===
Contributors: Developer-blog
Tags: payment,module,woocommerce,shopp
Requires at least: 3.0
Tested up to: 3.5.1
Stable tag: 0.0.0

This plugin only works in WooCommerce 2.0 or newer

== Description ==
Oink payment gateway for WooCommerce

== Installation ==

Installation of the module

1. Upload `vp-wp-checkout.zip` to `/wp-content/plugins/` directory or download and install it throught wordpress repo.
2. Activate the plugin through the 'Plugins' menu in WordPress 
3. Fill out the needed values in the WooCommerce/Shopp Payment Gateways page

== Screenshots ==

