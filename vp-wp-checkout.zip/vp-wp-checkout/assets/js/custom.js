(function ($, VPCheckout) {
    /*
     * Specific project code goes here
     *
     * for example
     *
     *  VPCheckout.afterLogin.post = function (value, args) {
     *      $('.box-black .content_title').hide();
     *      $('.box-black:eq(1)').hide()
     *  };
     *
     * Hooks works like this:
     *  Pre
     *      args = pre(...args)
     *  Post
     *      result = post(result, [args])
     *
     */
})(window.jQuery, window.VPCheckout);