<?php
/**
 * @package VirtualPiggy.Services.Interfaces
 */
    interface ICartService
    {
        public function GetCurrentCart();
        public function GetCurrentWishlist();
    }
?>
