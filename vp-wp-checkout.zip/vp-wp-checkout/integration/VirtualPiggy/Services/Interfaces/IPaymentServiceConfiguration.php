<?php
/**
 * @package VirtualPiggy.Services.Interfaces
 */
    interface IPaymentServiceConfiguration
    {
        public function GetServiceConfiguration();
    }
?>
